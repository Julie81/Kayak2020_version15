package fr.gleizes.kayak2020_version15;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;

import android.location.Location;
import android.location.LocationListener;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//     https://console.developers.google.com/flows/enableapi?apiid=maps_android_backend&keyType=CLIENT_SIDE_ANDROID&r=B3:17:02:47:C5:9E:C6:E4:7A:53:60:6F:03:3B:E4:14:90:03:65:43\%3Bcom.example.Kayak_2020

public class ConfigurationTrajet extends AppCompatActivity implements OnMapReadyCallback {
    //initialisation des variables
    Button button, buttonlink, buttonstart;
    GoogleMap gMap;
    Polyline path;
    List list = new ArrayList();
    int j;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_trajectoire);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment supportMapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.google_map);
        supportMapFragment.getMapAsync(this);


    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        gMap = googleMap;
        gMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE); //mettre en mode satelite
        gMap.setMyLocationEnabled(true); // afficher sa localisation
        button = findViewById(R.id.button);  //button clear
        buttonlink=findViewById(R.id.buttonrelier);
        buttonstart=findViewById(R.id.buttonstart);

        //list = list;
        j = 0;
        gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                //creat marker
                MarkerOptions markerOptions = new MarkerOptions();
                //set marker pos
                markerOptions.position(latLng);
                //set lat et long on map
                markerOptions.title(String.valueOf(j));
                j = j+1;
                list.add(latLng);
                //list.add(latLng.longitude);
                //ad marker on map
                gMap.addMarker(markerOptions);
            }
        });

        button.setOnClickListener(new View.OnClickListener() { //nettoyer clear la map pour les marqueurs
            @Override
            public void onClick(View view) {
                gMap.clear(); // on nettoie la map
                list.clear(); // on vide la list
                j=0;
            }
        });
        buttonlink.setOnClickListener(new View.OnClickListener() { //configuration du bouton link
            @Override
            public void onClick(View view) {
                PolylineOptions polylineOptions = new PolylineOptions().addAll(list).clickable(true); //nous ajoutons toute la liste
                path = gMap.addPolyline(polylineOptions);

                path.setColor(Color.parseColor("#00ff00")); //couleur verte
                path.setWidth(10); // taille du traie


            }

        });

        buttonstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openactivity();

            }
        });


    }
    public void openactivity(){
        Intent intent = new Intent(this, navigationGuiding.class);
        intent.putExtra("teste",34);
        intent.putExtra("lalist", (Serializable) list);
        //intent.putExtra("lalist", (Parcelable) list);
        startActivity(intent);

    }
}
